#!/usr/bin/env python3
"""M6 integration acceptance: prior zones, new obstacle, and two real goals."""
import json
import math
import os
from pathlib import Path
import subprocess
import time
import uuid
from collections import deque

from action_msgs.msg import GoalStatus
from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import ComputePathToPose
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import JointState, LaserScan
import rclpy
from rclpy.action import ActionClient
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile, DurabilityPolicy, qos_profile_sensor_data

from navigation_smoke_test import NavigationSmokeTest


class MissionTest(NavigationSmokeTest):
    def __init__(self):
        super().__init__()
        self.terrain = None
        self.costmap = None
        self.scan_evidence = None
        self.joint_stamps = deque(maxlen=31)
        self.joint_rate = None
        self.planner = ActionClient(self, ComputePathToPose, '/compute_path_to_pose')
        self.create_subscription(DiagnosticArray, '/mooncar/terrain/status', self.on_status, 10)
        self.create_subscription(LaserScan, '/mooncar/scan', self.on_scan, qos_profile_sensor_data)
        self.create_subscription(JointState, '/joint_states', self.on_joint_state, 10)
        self.create_subscription(OccupancyGrid, '/global_costmap/costmap',
                                 self.on_costmap, QoSProfile(depth=1,
                                 durability=DurabilityPolicy.TRANSIENT_LOCAL))
        self.evidence = {}
        self.max_position_variance = 0.0

    def on_odometry(self, msg):
        super().on_odometry(msg)
        variances = (msg.pose.covariance[0], msg.pose.covariance[7])
        variance = max(variances)
        self.max_position_variance = max(self.max_position_variance, variance)
        if not all(math.isfinite(v) and 0 <= v <= 25.0 for v in variances):
            raise RuntimeError('Filtered odometry covariance diverged')

    @staticmethod
    def ground_truth():
        result = subprocess.run(['gz', 'topic', '-e', '-t', '/world/lunar_yard/pose/info',
                                 '-n', '1', '--json-output'], capture_output=True,
                                text=True, check=True, timeout=15)
        # Gazebo may print another queued sample before --num 1 shuts down.
        poses = json.JSONDecoder().raw_decode(result.stdout.lstrip())[0]['pose']
        pose = next(p['position'] for p in poses if p.get('name') == 'mooncar')
        return float(pose.get('x', 0)), float(pose.get('y', 0))

    def on_joint_state(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self.joint_stamps and stamp <= self.joint_stamps[-1]:
            self.joint_stamps.clear()
            self.joint_rate = None
        self.joint_stamps.append(stamp)
        if len(self.joint_stamps) == self.joint_stamps.maxlen:
            self.joint_rate = (len(self.joint_stamps)-1)/(stamp-self.joint_stamps[0])

    def on_scan(self, msg):
        valid = [v for v in msg.ranges if math.isfinite(v) and msg.range_min+0.02 < v < msg.range_max]
        if len(valid) >= 10 and max(valid)-min(valid) > 0.2:
            self.scan_evidence = {'finite_returns': len(valid), 'min_m': min(valid), 'max_m': max(valid)}

    def on_status(self, msg):
        for status in msg.status:
            if status.name == 'terrain_geometry' and status.level == DiagnosticStatus.OK:
                self.terrain = {v.key: v.value for v in status.values}

    def on_costmap(self, msg):
        self.costmap = msg

    def wait(self, predicate, message, timeout=45):
        deadline = time.monotonic() + timeout
        while not predicate() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
        if not predicate():
            raise RuntimeError(message)

    def plan(self, start, end):
        if not self.planner.wait_for_server(timeout_sec=30):
            raise RuntimeError('Planner unavailable')
        goal = ComputePathToPose.Goal()
        goal.use_start = True
        goal.planner_id = 'GridBased'
        for field, xy in [('start', start), ('goal', end)]:
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.header.stamp = self.get_clock().now().to_msg()
            pose.pose.position.x, pose.pose.position.y = xy
            pose.pose.orientation.w = 1.0
            setattr(goal, field, pose)
        future = self.planner.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future, timeout_sec=30)
        if not future.done() or not future.result().accepted:
            raise RuntimeError('Planning request rejected or timed out')
        result = future.result().get_result_async()
        rclpy.spin_until_future_complete(self, result, timeout_sec=30)
        if not result.done() or result.result().status != GoalStatus.STATUS_SUCCEEDED:
            raise RuntimeError('Planning failed')
        points = [(p.pose.position.x, p.pose.position.y) for p in result.result().result.path.poses]
        if not points:
            raise RuntimeError('Planner returned empty path')
        return points

    def occupied(self, x, y):
        if self.costmap is None:
            return False
        info = self.costmap.info
        col, row = int((x-info.origin.position.x)/info.resolution), int((y-info.origin.position.y)/info.resolution)
        return (0 <= col < info.width and 0 <= row < info.height and
                self.costmap.data[row*info.width+col] >= 99)

    def obstacle_surface_observed(self, x, y):
        # A laser sees the near surface, not the unobserved box interior.
        if self.costmap is None:
            return False
        return any(self.occupied(x+dx*0.05, y+dy*0.05)
                   for dx in range(-10, 11) for dy in range(-10, 11))

    def run_mission(self):
        self.wait(lambda: self.joint_rate is not None, 'No sustained wheel-state stream')
        if not 20.0 <= self.joint_rate <= 35.0:
            raise RuntimeError(f'Wheel-state rate is {self.joint_rate:.1f} Hz in simulation time; expected 30 Hz')
        self.evidence['joint_states_hz_sim'] = self.joint_rate
        self.wait(lambda: self.scan_evidence is not None,
                  'Lidar has no varied obstacle returns in the known test yard; check rendering')
        self.evidence['live_lidar'] = self.scan_evidence
        self.wait(lambda: self.terrain is not None, 'No valid depth terrain observation')
        self.wait(lambda: self.occupied(-1.5, -0.8), 'Known soil zone absent from global costmap')
        self.evidence['live_depth'] = self.terrain
        path = self.plan((0.5, -0.8), (-3.0, -0.8))
        clearance = min(math.hypot(x+1.5, y+0.8) for x, y in path)
        if clearance < 0.65:
            raise RuntimeError('Planned path crossed keepout zone')
        self.evidence['keepout_center_clearance_m'] = clearance
        self.get_logger().info(f'Keepout detour passed; center clearance={clearance:.2f} m')

        start, end, center = (0.5, 2.5), (3.5, 2.5), (1.5, 2.5)
        before = self.plan(start, end)
        baseline = min(math.hypot(x-center[0], y-center[1]) for x, y in before)
        if baseline > 0.4:
            raise RuntimeError('Dynamic-obstacle baseline is already obstructed')
        name = 'm6_obstacle_' + uuid.uuid4().hex[:8]
        sdf = (f'<sdf version="1.9"><model name="{name}"><static>true</static>'
               '<link name="box">'
               '<collision name="c"><geometry><box><size>0.8 0.8 0.8</size></box></geometry></collision>'
               '<visual name="v"><geometry><box><size>0.8 0.8 0.8</size></box></geometry></visual>'
               '</link></model></sdf>')
        try:
            subprocess.run(['ros2', 'run', 'ros_gz_sim', 'create', '-world', 'lunar_yard',
                            '-string', sdf, '-x', '1.5', '-y', '2.5', '-z', '0.4'],
                           check=True, timeout=30)
            self.wait(lambda: self.obstacle_surface_observed(*center), 'New obstacle absent from costmap', 60)
            after = self.plan(start, end)
            clearance = min(math.hypot(x-center[0], y-center[1]) for x, y in after)
            if clearance < 0.5:
                raise RuntimeError('Replanned path did not avoid the new obstacle')
            self.evidence['new_obstacle'] = {'baseline_center_distance_m': baseline,
                                           'replanned_center_distance_m': clearance}
            self.get_logger().info(f'New obstacle replanning passed; clearance={clearance:.2f} m')
        finally:
            result = subprocess.run(['gz', 'service', '-s', '/world/lunar_yard/remove',
                '--reqtype', 'gz.msgs.Entity', '--reptype', 'gz.msgs.Boolean',
                '--timeout', '5000', '--req', f'name: "{name}" type: MODEL'],
                capture_output=True, text=True, timeout=10)
            if result.returncode or 'true' not in result.stdout:
                raise RuntimeError('Failed to remove acceptance obstacle: ' + result.stdout + result.stderr)

        self.evidence['goals'] = []
        for x, y, minimum in [(1.5, 0.0, 0.5), (3.5, 3.0, 2.0)]:
            self.set_parameters([Parameter('goal_x', value=x), Parameter('goal_y', value=y),
                                 Parameter('min_displacement_m', value=minimum)])
            self.run()
            truth = self.ground_truth()
            error = math.hypot(truth[0]-x, truth[1]-y)
            if error > 0.4:
                raise RuntimeError(f'Goal succeeded but Gazebo ground-truth error is {error:.2f} m; '
                                   f'truth={truth}, goal={(x, y)}, odom={self.position}')
            self.evidence['goals'].append({'x': x, 'y': y, 'status': 'SUCCEEDED',
                                           'final_odom': self.position,
                                           'ground_truth': truth, 'goal_error_m': error})
        self.evidence['max_position_variance_m2'] = self.max_position_variance
        output = Path(os.environ.get('MOONCAR_M6_REPORT', str(Path.home()/'mooncar_m6_acceptance.json')))
        output.write_text(json.dumps(self.evidence, indent=2) + '\n')
        self.get_logger().info(f'M6 acceptance passed. Evidence: {output}')


def main():
    output = Path(os.environ.get('MOONCAR_M6_REPORT', str(Path.home()/'mooncar_m6_acceptance.json')))
    output.unlink(missing_ok=True)
    rclpy.init()
    node = MissionTest()
    try:
        node.run_mission()
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
