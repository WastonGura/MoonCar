"""Task boundary checks and HTTP isolation; real spawn evidence is recorded separately."""
import http.client
import json
import math
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from urllib.parse import quote
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[4]/'scripts'))
from simulation_experiment import SimulationExperiment, validate_task, survey_world
from map_workbench import create_server, SimulationProxy
from terrain_map import TerrainMap


class ExperimentTests(unittest.TestCase):
    def test_windows_proxy_keeps_browser_requests_same_origin(self):
        with self.assertRaises(ValueError):SimulationProxy('http://external.invalid:8766')
        with tempfile.TemporaryDirectory() as directory:
            target=Mock();target.state.return_value=dict(enabled=True,phase='idle');target.command.return_value=dict(token='test')
            backend=create_server(directory,port=0,simulation=target)
            proxy=SimulationProxy(f'http://127.0.0.1:{backend.server_port}')
            frontend=create_server(directory,port=0,simulation=proxy)
            threads=[threading.Thread(target=server.serve_forever,daemon=True) for server in (backend,frontend)]
            for thread in threads:thread.start()
            client=http.client.HTTPConnection('127.0.0.1',frontend.server_port)
            try:
                client.request('GET','/api/simulation');response=client.getresponse()
                self.assertEqual(json.loads(response.read()),dict(enabled=True,phase='idle'))
                body=dict(experiment='test',goal=[4.8,3])
                for origin,status in [('http://external.invalid',403),(f'http://127.0.0.1:{frontend.server_port}',200)]:
                    client.request('POST','/api/simulation/move',json.dumps(body),{'Content-Type':'application/json','Origin':origin})
                    response=client.getresponse();self.assertEqual(response.status,status);response.read()
                target.command.assert_called_once_with('move',body)
            finally:
                client.close()
                for server in (frontend,backend):server.shutdown();server.server_close()
                for thread in threads:thread.join()

    def test_missing_sensor_archive_and_exited_launch_report_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            sim=SimulationExperiment.__new__(SimulationExperiment)
            sim.lock=threading.Lock();sim.directory=Path(directory)
            sim.current=dict(id='experiment-test');sim.phase='starting';sim.error='';sim.started_at=10
            sim.process=Mock();sim.process.poll.return_value=None
            with patch('simulation_experiment.time.monotonic',return_value=131):
                self.assertEqual(sim.state()['phase'],'failed')
            sim.process.poll.return_value=1
            self.assertEqual(sim.state()['phase'],'failed')
            sim.phase='stopped'
            self.assertEqual(sim.state()['phase'],'stopped')

    def test_task_validation_and_nested_archive_api(self):
        world=survey_world()
        self.assertEqual(world.find('.//plane/size').text.strip(),'50 50')
        self.assertEqual(len([m for m in world.findall('./world/model') if m.get('name','').startswith('survey_landmark_')]),32)
        self.assertEqual(validate_task(dict(version=1,region=[-25,-25,25,25],start=[3.5,3,0]))['region'],[-25,-25,25,25])
        with self.assertRaises(ValueError):validate_task(dict(version=1,region=[-25,-25,25,25],start=[-20,-20,0]))
        valid = dict(version=1, region=[-1,-2,6,4], start=[.5,0,0])
        self.assertEqual(validate_task(valid), valid)
        self.assertEqual(validate_task(dict(valid,start=[3.5,3,math.pi/2]))['start'], [3.5,3,math.pi/2])
        invalid = [dict(valid,start=[2,1.4,0]), dict(valid,start=[4,0,0]),
                   dict(valid,start=[True,0,0]),dict(valid,start=[float('nan'),0,0]),
                   dict(valid,start=[26,0,0]),dict(valid,start=[0,0,4]),
                   dict(valid,region=[1,1,0,0]),dict(valid,version=True),dict(valid,extra='x')]
        for task in invalid:
            with self.assertRaises(ValueError):validate_task(task)
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory)/'experiment-test';folder.mkdir()
            terrain=TerrainMap(source='unit test');terrain.add_frame([[0,0,0],[.1,0,0],[0,.1,0]],1);terrain.save(folder/'survey.npz')
            evidence=folder/'research/autonomy-test';evidence.mkdir(parents=True);terrain.save(evidence/'observations.npz')
            simulation=Mock();simulation.state.return_value=dict(enabled=True,phase='idle');simulation.apply.return_value=dict(accepted=True)
            server=create_server(directory,port=0,simulation=simulation)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            client=http.client.HTTPConnection('127.0.0.1',server.server_port)
            try:
                client.request('GET','/api/task?task='+quote(json.dumps(valid)))
                response=client.getresponse();self.assertEqual(response.status,200)
                self.assertIn('mooncar-experiment.json',response.getheader('Content-Disposition'))
                self.assertEqual(json.loads(response.read()),valid)
                for path in ['/api/sessions','/api/info?session=experiment-test/survey.npz','/api/simulation']:
                    client.request('GET',path);response=client.getresponse();self.assertEqual(response.status,200);body=json.loads(response.read())
                    if path=='/api/sessions':self.assertEqual(body['sessions'],[dict(name='experiment-test/survey.npz')])
                for origin,status in [('http://external.invalid',403),(f'http://127.0.0.1:{server.server_port}',200)]:
                    client.request('POST','/api/simulation/apply',json.dumps(valid),{'Content-Type':'application/json','Origin':origin})
                    response=client.getresponse();self.assertEqual(response.status,status);response.read()
                simulation.apply.assert_called_once_with(valid)
                for path in ['../survey.npz','experiment-test/../survey.npz','%2Fetc%2Ftest.npz','experiment-test%5Csurvey.npz']:
                    client.request('GET','/api/info?session='+path);response=client.getresponse();self.assertEqual(response.status,400);response.read()
            finally:
                client.close();server.shutdown();server.server_close();thread.join()


if __name__=='__main__':unittest.main()
