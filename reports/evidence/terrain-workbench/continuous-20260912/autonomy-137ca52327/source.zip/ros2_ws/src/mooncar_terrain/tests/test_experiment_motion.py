"""Run in the existing ROS environment; verifies sensor health and lease/boundary stops."""
from pathlib import Path
import sys
import threading
import time
import unittest
from unittest.mock import Mock

sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'scripts'))
try:
    from experiment_motion import ExperimentMotion, within_region
    from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus
except ImportError:
    ExperimentMotion=None


@unittest.skipIf(ExperimentMotion is None,'Requires the existing sourced ROS environment')
class MotionTests(unittest.TestCase):
    def test_costmap_freshness_uses_simulation_time_with_wall_disconnect_guard(self):
        from nav_msgs.msg import OccupancyGrid
        state=Mock();state.grid=OccupancyGrid();state.grid.header.stamp.sec=10
        state.grid_received=time.monotonic()-8
        state.get_clock.return_value.now.return_value.nanoseconds=11_000_000_000
        self.assertTrue(ExperimentMotion.grid_fresh(state))
        state.get_clock.return_value.now.return_value.nanoseconds=14_000_000_000
        self.assertFalse(ExperimentMotion.grid_fresh(state))
        state.get_clock.return_value.now.return_value.nanoseconds=9_000_000_000
        self.assertFalse(ExperimentMotion.grid_fresh(state))
        state.get_clock.return_value.now.return_value.nanoseconds=11_000_000_000
        state.grid_received=time.monotonic()-31
        self.assertFalse(ExperimentMotion.grid_fresh(state))
        state.grid=None;self.assertFalse(ExperimentMotion.grid_fresh(state))

    def test_health_and_motion_stops(self):
        state=Mock();state.last_depth=0
        ExperimentMotion.depth(state,DiagnosticArray(status=[DiagnosticStatus(name='map_recorder',level=DiagnosticStatus.OK,message='Depth active')]))
        self.assertGreater(state.last_depth,0)
        self.assertTrue(within_region([-1,-2,8,6],3.5,3,0))
        self.assertFalse(within_region([-1,-2,8,6],7.8,3,0))
        for stale,pose,reason in [(True,dict(x=3.5,y=3,yaw=0),'页面失联'),(False,dict(x=7.8,y=3,yaw=0),'接近探测区域边界')]:
            state=Mock();state.lock=threading.RLock();state.active=True;state.phase='executing'
            state.started=state.last_depth=time.monotonic();state.last_heartbeat=0 if stale else time.monotonic()
            state.mission_limits=None
            state.sim_started=0.;state.sim_budget=180.;state.get_clock.return_value.now.return_value.nanoseconds=10_000_000_000
            state.track=[[3.5,3,0]]
            state.region=[-1,-2,8,6];state.pose.return_value=pose
            pose['z']=0.
            state.cancel.side_effect=lambda _:setattr(state,'phase','cancelling')
            ExperimentMotion.tick(state)
            self.assertIn(reason,state.cancel.call_args.args[0])
            self.assertFalse(state.permit.publish.call_args.args[0].data)

    def test_goal_limits_feedback_and_simulation_timeout(self):
        from nav_msgs.msg import OccupancyGrid
        from nav2_msgs.action import NavigateToPose
        from types import SimpleNamespace
        grid=OccupancyGrid();grid.info.width=grid.info.height=3;grid.info.resolution=1.
        grid.data=[0,0,0,0,-1,0,0,0,100]
        state=Mock();state.grid=grid;state.grid_received=time.monotonic()
        ExperimentMotion.check_goal(state,[.2,.2])
        for target in ([4,0],[1.2,1.2],[2.2,2.2]):
            with self.assertRaises(ValueError):ExperimentMotion.check_goal(state,target)
        state.lock=threading.RLock();state.active=True;state.token='current';state.feedback={}
        feedback=NavigateToPose.Feedback();feedback.distance_remaining=3.5
        ExperimentMotion.on_feedback(state,SimpleNamespace(feedback=feedback),'old')
        self.assertEqual(state.feedback,{})
        ExperimentMotion.on_feedback(state,SimpleNamespace(feedback=feedback),'current')
        self.assertEqual(state.feedback['distance_remaining'],3.5)
        state.phase='executing';state.started=time.monotonic()-200
        state.mission_limits=None
        state.last_depth=state.last_heartbeat=time.monotonic();state.sim_started=0.;state.sim_budget=180.
        state.get_clock.return_value.now.return_value.nanoseconds=30_000_000_000
        state.pose.return_value=dict(x=3.5,y=3,z=0,yaw=0);state.region=[-1,-2,8,6];state.track=[[3.5,3,0]]
        ExperimentMotion.tick(state);state.cancel.assert_not_called()
        state.get_clock.return_value.now.return_value.nanoseconds=181_000_000_000
        ExperimentMotion.tick(state);self.assertIn('仿真时间预算',state.cancel.call_args.args[0])
        state.get_clock.return_value.now.return_value.nanoseconds=30_000_000_000
        state.mission_limits=dict(origin=[3.5,3],radius=10,deadline=20)
        ExperimentMotion.tick(state);self.assertIn('自主探测时间预算',state.cancel.call_args.args[0])
        state.mission_limits=dict(origin=[0,0],radius=2,deadline=100)
        ExperimentMotion.tick(state);self.assertIn('活动距离限制',state.cancel.call_args.args[0])

    def test_path_updates_ignore_previous_goal_and_stopped_task(self):
        from nav_msgs.msg import Path
        from geometry_msgs.msg import PoseStamped
        state=Mock();state.lock=threading.RLock();state.active=True;state.phase='executing';state.goal=[9,3]
        state.path=[]
        message=Path();message.header.frame_id='map';message.poses=[PoseStamped(),PoseStamped()]
        message.poses[-1].pose.position.x=4.
        ExperimentMotion.on_path(state,message);self.assertEqual(state.path,[])
        message.poses[-1].pose.position.x=9.;message.poses[-1].pose.position.y=3.
        ExperimentMotion.on_path(state,message);self.assertEqual(state.path[-1],[9,3,0])
        state.active=False;message.poses[0].pose.position.x=2.
        ExperimentMotion.on_path(state,message);self.assertEqual(state.path[0],[0,0,0])


if __name__=='__main__':unittest.main()
