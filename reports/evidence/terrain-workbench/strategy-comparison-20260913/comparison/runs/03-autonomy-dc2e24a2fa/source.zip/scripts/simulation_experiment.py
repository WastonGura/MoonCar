"""Own an isolated Gazebo experiment, camera view and explicitly leased Nav2 goals."""
import json
import copy
import math
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import uuid
import xml.etree.ElementTree as ET
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
WORLD = ROOT / 'ros2_ws/src/mooncar_gazebo/worlds/lunar_yard.sdf'


def transform(element):
    pose = element.find('pose')
    if pose is not None and pose.attrib:
        raise ValueError('Unsupported world pose reference')
    x, y, z, r, p, a = map(float, element.findtext('pose', '0 0 0 0 0 0').split())
    cr, sr, cp, sp, ca, sa = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(a), math.sin(a)
    matrix = np.eye(4)
    matrix[:3, :3] = [[ca*cp, ca*sp*sr-sa*cr, ca*sp*cr+sa*sr],
                      [sa*cp, sa*sp*sr+ca*cr, sa*sp*cr-ca*sr], [-sp, cp*sr, cp*cr]]
    matrix[:3, 3] = [x, y, z]
    return matrix


def survey_world():
    """50 m square with distributed geometry; never used as an observation map."""
    tree=ET.parse(WORLD);world=tree.getroot().find('world')
    templates=[world.find(f"model[@name='{name}']") for name in
               ('scattered_rock_c','gentle_ramp','north_ridge','rock_field_marker_a')]
    count=0
    for row,y in enumerate((-20,-12,-4,4,12,20)):
        for col,x in enumerate((-20,-12,-4,4,12,20)):
            if abs(x)<8 and abs(y)<8:continue
            model=copy.deepcopy(templates[(row+col)%len(templates)])
            model.set('name',f'survey_landmark_{count}');count+=1
            pose=model.find('pose');values=list(map(float,pose.text.split()))
            values[0]=x;values[1]=y;values[5]=(row%3)*.4
            pose.text=' '.join(map(str,values));world.append(model)
    return tree


def spawn_obstacles():
    # Conservative bounds are setup-only world metadata, never sensor observations.
    obstacles = []
    for model in survey_world().findall('./world/model'):
        for link in model.findall('link'):
            for collision in link.findall('collision'):
                g = collision.find('geometry')
                if g.find('plane') is not None:
                    continue
                if g.find('box') is not None:
                    extent = np.array(list(map(float, g.findtext('box/size').split()))) / 2
                elif g.find('ellipsoid') is not None:
                    extent = np.array(list(map(float, g.findtext('ellipsoid/radii').split())))
                elif g.find('cylinder') is not None:
                    extent = np.array([float(g.findtext('cylinder/radius'))]*2 + [float(g.findtext('cylinder/length'))/2])
                else:
                    raise ValueError('Unsupported spawn collision geometry')
                t = transform(model) @ transform(link) @ transform(collision)
                half = np.abs(t[:3,:3]) @ extent
                obstacles.append((t[:2,3]-half[:2], t[:2,3]+half[:2]))
    return obstacles


def validate_task(body):
    if not isinstance(body, dict) or set(body) != {'version', 'region', 'start'} or type(body['version']) is not int or body['version'] != 1:
        raise ValueError('任务格式无效，请重新保存任务')
    region, start = body['region'], body['start']
    if not isinstance(region, list) or len(region) != 4 or not isinstance(start, list) or len(start) != 3:
        raise ValueError('需要矩形区域及起点 X、Y、朝向')
    if not all(type(v) in (int, float) and math.isfinite(v) for v in region+start):
        raise ValueError('坐标和朝向必须为有限数值')
    x0, y0, x1, y1 = region
    x, y, yaw = start
    if not all(-25 <= v <= 25 for v in region+start[:2]) or not (.5 <= x1-x0 <= 50 and .5 <= y1-y0 <= 50) or abs(yaw) > math.pi:
        raise ValueError('坐标范围为 -25 至 25 米；区域每边至少 0.5 米；朝向为 -180 至 180 度')
    hx = .43*abs(math.cos(yaw)) + .36*abs(math.sin(yaw)) + .1
    hy = .43*abs(math.sin(yaw)) + .36*abs(math.cos(yaw)) + .1
    for low, high in spawn_obstacles():
        if x+hx >= low[0] and x-hx <= high[0] and y+hy >= low[1] and y-hy <= high[1]:
            raise ValueError('起点车体与场景障碍或坡面重叠，请选择周围平地')
    return dict(version=1, region=list(map(float, region)), start=list(map(float, start)))


class SimulationExperiment:
    def __init__(self, directory):
        if os.name != 'posix' or not os.environ.get('ROS_DISTRO'):
            raise ValueError('仿真模式需要已 source ROS 的独立 Ubuntu 环境')
        from ament_index_python.packages import get_package_share_directory
        installed_world = Path(get_package_share_directory('mooncar_gazebo'))/'worlds/lunar_yard.sdf'
        if installed_world.read_bytes() != WORLD.read_bytes():
            raise ValueError('已构建的 Gazebo 场景与当前代码不一致，请先重新构建 ROS 工作区')
        self.directory = Path(directory).resolve()
        self.lock = threading.Lock()
        self.process = self.log = None
        self.current = None
        self.phase, self.error = 'idle', ''
        self.worker = None
        self.started_at = None
        import rclpy
        from rclpy.executors import MultiThreadedExecutor
        from rclpy.signals import SignalHandlerOptions
        from experiment_motion import ExperimentMotion
        os.environ['ROS_DOMAIN_ID']='89'
        rclpy.init(args=['--ros-args','-p','use_sim_time:=true'],signal_handler_options=SignalHandlerOptions.NO)
        self.motion=ExperimentMotion()
        from autonomous_survey import AutonomousSurvey
        self.autonomy=AutonomousSurvey(self.motion)
        self.executor=MultiThreadedExecutor(num_threads=2);self.executor.add_node(self.motion)
        self.ros_thread=threading.Thread(target=self.executor.spin,daemon=True);self.ros_thread.start()

    def state(self):
        with self.lock:
            current = self.current
            phase, error = self.phase, self.error
            if phase == 'starting' and self.process and self.process.poll() is not None:
                phase, error = 'failed', '仿真进程退出，请检查该实验的 simulation.log'
            archives = sorted((self.directory/current['id']).glob('*.npz')) if current else []
            # "recording" means a new sensor archive exists, not that area exploration ran.
            if phase == 'starting' and archives:
                phase = 'recording'
            elif phase == 'starting' and self.started_at and time.monotonic()-self.started_at > 120:
                phase, error = 'failed', '超过 120 秒未收到采集档案，请检查定位、传感器和 simulation.log；可结束后重试'
            return dict(enabled=True, phase=phase, error=error, task=current,
                        motion=self.motion.state() if hasattr(self,'motion') else {},
                        autonomy=self.autonomy.state() if hasattr(self,'autonomy') else {},
                        session=str(archives[-1].relative_to(self.directory)).replace('\\','/') if archives else None)

    def image(self):
        if not self.current or self.phase not in ('starting',):
            raise ValueError('仿真现场尚未启动')
        path=self.directory/self.current['id']/'scene.jpg'
        if not path.is_file() or time.time()-path.stat().st_mtime>3:
            raise ValueError('等待 Gazebo 现场画面')
        return path.read_bytes()

    def command(self,action,body):
        with self.lock:
            if action=='cancel':
                self.autonomy.stop()
                return self.motion.cancel('已手动停止导航')
            if action=='explore_stop':return self.autonomy.stop()
            if action=='heartbeat':return self.motion.heartbeat(body)
            if action=='explore' and self.phase=='starting' and self.current and self.process.poll() is None:
                return self.autonomy.start(body,self.current,self.directory)
            if action=='move' and self.phase=='starting' and self.current and self.process.poll() is None:
                if self.autonomy.state()['active']:raise ValueError('请先结束自主探测，再手动指定目标')
                return self.motion.start(body,self.current)
            raise ValueError('当前仿真实验不可执行导航')

    def _stop(self):
        if hasattr(self,'autonomy'):
            self.autonomy.stop('实验正在结束')
            if self.autonomy.worker:self.autonomy.worker.join(timeout=10)
        if hasattr(self,'motion'):self.motion.cancel('实验正在结束')
        def alive_group(pgid):
            # Container PID 1 may retain exited grandchildren as zombies; they cannot run.
            for entry in Path('/proc').glob('[0-9]*/stat'):
                try:
                    fields = entry.read_text().rsplit(')',1)[1].split()
                    if int(fields[2]) == pgid and fields[0] not in ('Z','X'):
                        return True
                except (OSError, ValueError, IndexError):
                    continue
            return False
        if self.process is not None:
            pgid = self.process.pid
            for sig, timeout in ((signal.SIGINT, 12), (signal.SIGTERM, 5), (signal.SIGKILL, 3)):
                try:
                    os.killpg(pgid, sig)
                except ProcessLookupError:
                    break
                deadline = time.monotonic()+timeout
                while time.monotonic() < deadline:
                    self.process.poll()
                    if not alive_group(pgid):
                        break
                    time.sleep(.1)
                else:
                    continue
                break
            else:
                raise RuntimeError('旧仿真进程未退出，禁止创建新实验')
            self.process.wait(timeout=2)
            self.process = None
        # Old publishers must be gone before clearing their cached TF/map/quality.
        if hasattr(self,'motion'):self.motion.reset()
        if self.log:
            self.log.close()
            self.log = None

    def apply(self, body):
        task = validate_task(body)  # Reject bad requests before stopping the current experiment.
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise ValueError('正在切换实验，请等待完成')
            self.phase, self.error = 'restarting', ''
            def run():
                try:
                    self._stop()
                    ident = 'experiment-'+uuid.uuid4().hex[:12]
                    folder = self.directory/ident
                    folder.mkdir()
                    (folder/'task.json').write_text(json.dumps(task, indent=2)+'\n', encoding='utf-8')
                    survey_world().write(folder/'survey_yard.sdf',encoding='unicode',xml_declaration=True)
                    x,y,yaw = task['start']
                    gui=ET.parse(WORLD).find('./world/gui')
                    gui.find("plugin[@filename='MinimalScene']/camera_pose").text=f'{x-4} {y-5} 4.5 0 0.55 0.90'
                    tree=gui.find("plugin[@filename='EntityTree']")
                    if tree is not None:gui.remove(tree)
                    config='<window><width>1100</width><height>740</height></window>\n'+''.join(ET.tostring(p,encoding='unicode') for p in gui)
                    (folder/'gui.config').write_text(config,encoding='utf-8')
                    env = dict(os.environ, ROS_DOMAIN_ID='89', GZ_PARTITION='mooncar-'+ident)
                    self.log = (folder/'simulation.log').open('w')
                    command = ['xvfb-run','-a','-s','-screen 0 1120x760x24','ros2','launch',str(ROOT/'containers/experiment.launch.py'),
                               f'initial_x:={x}',f'initial_y:={y}',f'initial_yaw:={yaw}', f'output_directory:={folder}']
                    process = subprocess.Popen(command, stdout=self.log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
                    with self.lock:
                        self.process, self.current = process, dict(task, id=ident)
                        self.started_at = time.monotonic()
                        self.phase = 'starting'
                except Exception as exc:
                    with self.lock:
                        self.phase, self.error = 'failed', str(exc)
            self.worker = threading.Thread(target=run, daemon=True)
            self.worker.start()
        return dict(accepted=True)

    def stop(self):
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise ValueError('正在切换实验，请等待完成')
            self.phase = 'stopping'
            def run():
                try:
                    self._stop()
                    with self.lock:
                        self.phase = 'stopped'
                except Exception as exc:
                    with self.lock:
                        self.phase, self.error = 'failed', str(exc)
            self.worker = threading.Thread(target=run, daemon=True)
            self.worker.start()
        return dict(accepted=True)

    def close(self):
        if self.worker:
            self.worker.join()
        self._stop()
        self.executor.shutdown();self.ros_thread.join(timeout=3)
        self.motion.destroy_node()
        import rclpy
        rclpy.shutdown()
