#!/usr/bin/env python3
"""Record timestamped depth observations separately from M6 safety decisions."""
from datetime import datetime, timezone
from pathlib import Path
import time

from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import Header
from std_msgs.msg import String
import json
from std_srvs.srv import Trigger
from tf2_ros import Buffer, TransformException, TransformListener

from terrain_map import TerrainMap


def keyframe_needed(frames, translation, quaternion, distance, angle):
    if len(frames) < 3:
        return True
    previous_t, previous_q = frames[-1][2:]
    q = np.asarray(quaternion, dtype=float)
    cosine = abs(np.dot(previous_q, q) / (np.linalg.norm(previous_q) * np.linalg.norm(q)))
    rotation = np.degrees(2 * np.arccos(np.clip(cosine, 0., 1.)))
    return np.linalg.norm(np.asarray(translation)-previous_t) >= distance or rotation >= angle


class MapRecorder(Node):
    def __init__(self):
        super().__init__('mooncar_map_recorder')
        for name, value in [('frame', 'map'), ('resolution', .25), ('voxel_size', .05),
                            ('output_directory', str(Path.home() / '.local/share/mooncar/maps')),
                            ('source', 'ROS depth observations; physical/simulation provenance unspecified'),
                            ('save_interval', 5.), ('keyframe_distance', .05), ('keyframe_angle', 5.)]:
            self.declare_parameter(name, value)
        self.terrain = TerrainMap(self.get_parameter('resolution').value,
                                  self.get_parameter('voxel_size').value,
                                  self.get_parameter('frame').value,
                                  self.get_parameter('source').value)
        self.keyframe_distance = self.get_parameter('keyframe_distance').value
        self.keyframe_angle = self.get_parameter('keyframe_angle').value
        if not all(np.isfinite(v) and v > 0 for v in (self.keyframe_distance, self.keyframe_angle)):
            raise ValueError('Keyframe thresholds must be finite and positive')
        self.directory = Path(self.get_parameter('output_directory').value).expanduser()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / f'survey-{datetime.now(timezone.utc):%Y%m%dT%H%M%S%fZ}.npz'
        self.buffer = Buffer()
        self.listener = TransformListener(self.buffer, self)
        self.pending = None
        self.dirty = False
        self.last_observation = 0.
        self.last_stamp = None
        self.reset_detected = False
        self.cloud_pub = self.create_publisher(PointCloud2, '/mooncar/map/points', 1)
        self.status_pub = self.create_publisher(DiagnosticArray, '/mooncar/map/status', 1)
        self.quality_pub = self.create_publisher(String, '/mooncar/map/quality', 1)
        self.create_timer(1.,lambda:self.quality_pub.publish(String(data=json.dumps(self.terrain.quality()))))
        self.create_subscription(PointCloud2, '/mooncar/terrain/observations', self.on_cloud,
                                 qos_profile_sensor_data)
        self.create_timer(.1, self.process_pending)
        interval = self.get_parameter('save_interval').value
        if interval < 1. or not np.isfinite(interval):
            raise ValueError('save_interval must be finite and >= 1 second')
        self.create_timer(interval, self.save_periodic)
        self.create_service(Trigger, '/mooncar/map/save', self.save_service)
        self.get_logger().info(f'Observation archive: {self.path}')

    def status(self, level, message):
        status = DiagnosticStatus(name='map_recorder', hardware_id='depth_camera',
                                  level=level, message=message,
                                  values=[KeyValue(key='archive', value=str(self.path)),
                                          KeyValue(key='frames', value=str(len(self.terrain.frames)))])
        self.status_pub.publish(DiagnosticArray(
            header=Header(stamp=self.get_clock().now().to_msg()), status=[status]))

    def on_cloud(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec / 1e9
        if self.last_stamp is not None and stamp < self.last_stamp:
            # Do not mix coordinate epochs after a simulation reset or bag rewind.
            self.reset_detected = True
            self.pending = None
            self.status(DiagnosticStatus.ERROR, 'Clock moved backwards; save and restart recorder for a new session')
            return
        self.last_stamp = stamp
        if not self.reset_detected and self.pending is None:
            self.pending = (msg, time.monotonic())

    def process_pending(self):
        if self.pending is None:
            return
        msg, received = self.pending
        stamp = rclpy.time.Time.from_msg(msg.header.stamp)
        if not self.buffer.can_transform(self.terrain.frame, msg.header.frame_id, stamp):
            if time.monotonic() - received > 3.:
                self.pending = None
                self.status(DiagnosticStatus.WARN, 'Timestamped pose unavailable; frame omitted')
            return
        self.pending = None
        try:
            points = point_cloud2.read_points_numpy(msg, field_names=('x', 'y', 'z'), skip_nans=True)
            transform = self.buffer.lookup_transform(self.terrain.frame, msg.header.frame_id, stamp)
            robot_transform = self.buffer.lookup_transform(self.terrain.frame, 'base_footprint', stamp)
            t, q = transform.transform.translation, transform.transform.rotation
            rt, rq = robot_transform.transform.translation, robot_transform.transform.rotation
            self.last_observation = time.monotonic()
            if not keyframe_needed(self.terrain.frames, (t.x,t.y,t.z), (q.x,q.y,q.z,q.w),
                                   self.keyframe_distance, self.keyframe_angle):
                self.status(DiagnosticStatus.OK, 'Depth active; pose unchanged, redundant frame omitted')
                return
            self.terrain.add_frame(points, stamp.nanoseconds / 1e9, (t.x, t.y, t.z), (q.x, q.y, q.z, q.w),
                                   (rt.x, rt.y, rt.z), (rq.x, rq.y, rq.z, rq.w))
            self.dirty = True
            self.last_observation = time.monotonic()
            self.status(DiagnosticStatus.OK, 'Depth frame recorded; historical pose errors are not corrected by loop closure')
        except (ValueError, TransformException) as error:
            self.status(DiagnosticStatus.WARN, str(error))

    def save_periodic(self):
        if self.dirty:
            try:
                self.save()
            except OSError as error:
                self.status(DiagnosticStatus.ERROR, f'Archive save failed: {error}')
        if self.reset_detected:
            self.status(DiagnosticStatus.ERROR, 'Clock reset; restart recorder with a new session')
        elif time.monotonic() - self.last_observation > 5.:
            self.status(DiagnosticStatus.STALE, 'No recent observations; saved map is historical')

    def save(self):
        self.terrain.save(self.path)
        self.dirty = False
        stamp = self.get_clock().now().to_msg()
        self.cloud_pub.publish(point_cloud2.create_cloud_xyz32(
            Header(stamp=stamp, frame_id=self.terrain.frame), self.terrain.cloud()))

    def save_service(self, request, response):
        try:
            self.save()
            response.success, response.message = True, str(self.path)
        except OSError as error:
            response.success, response.message = False, str(error)
        return response


def main():
    rclpy.init()
    node = MapRecorder()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.dirty:
            try:
                node.terrain.save(node.path)
            except OSError as error:
                node.get_logger().error(f'Final map save failed: {error}')
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
