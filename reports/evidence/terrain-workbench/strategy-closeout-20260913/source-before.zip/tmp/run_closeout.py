"""One bounded, frozen six-trial closeout; never tune or replace failed trials."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile
from datetime import datetime, timezone

ROOT = Path('/source')
sys.path.insert(0, str(ROOT/'scripts'))
from compare_survey_strategies import request, run, wait_for
from report_strategy_comparison import report
from survey_evaluation import write_json
from simulation_experiment import validate_task

OUT = Path('/evidence/strategy-closeout-20260913')
STARTS = [[-15., -16., 0.], [15., 16., 3.141592653589793]]


def sources():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for base in ('scripts', 'containers', 'ros2_ws/src', 'web')
            for p in sorted((ROOT/base).rglob('*'))
            if p.is_file() and p.suffix in ('.py', '.yaml', '.xacro', '.sdf', '.xml', '.sh', '.js', '.html', '.css', '.json')}


if sys.argv[1] == 'prepare':
    state = request()
    assert state['phase'] == 'stopped' and not state['motion']['active'] and not state['autonomy']['active']
    for start in STARTS:
        validate_task(dict(version=1, region=[-25,-25,25,25], start=start))
    OUT.mkdir(exist_ok=False)
    history = [{'experiment': p.parent.name, 'task': json.loads(p.read_text()),
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
               for p in sorted(Path('/evidence/frontend-experiments').glob('*/task.json'))]
    assert not any(h['task']['start'] == start for h in history for start in STARTS)
    write_json(OUT/'prior-tasks.json', history)
    protocol = dict(frozen_utc=datetime.now(timezone.utc).isoformat(), starts=STARTS,
        strategies=['nearest_view_v1','coverage_view_v1','surface_view_v1'], repeats=1,
        budget_seconds=90, radius=8, attempts=6,
        primary='valid_surface_gain_m2: final minus initial valid fitted area inside fixed ROI',
        secondary=['new_observed_area_m2','resampling_success_fraction','path_m','elapsed_seconds','actions_failed','actions_interrupted'],
        comparison='Per start; same 90 simsecond cap, early termination retained; no ratio or pooled winner substituted for primary',
        descriptive_gate='All six reports captured without runtime failure, and Surface primary exceeds both baselines at BOTH starts; otherwise no consistent descriptive advantage',
        inference='One run per strategy/start; no significance claim even if descriptive gate passes',
        scope='Previously unused start coordinates and peripheral arrangements in existing survey world; reused geometry templates, no strict independent-world or unseen-cell claim',
        model='Existing ONLINE v1 heuristics only; offline v5 excluded and remains unvalidated',
        stop='Six attempts once, no replacement, tuning, new model or automatic follow-up campaign; stop motion and report failures',
        reset='Existing runner restarts Gazebo, SLAM and empty archive each trial',
        source_sha256=sources())
    write_json(OUT/'protocol.json', protocol)
    with zipfile.ZipFile(OUT/'source-before.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in protocol['source_sha256']: archive.write(ROOT/name, name)
        archive.write(__file__, 'tmp/run_closeout.py')
    print('FROZEN six attempts, no model tuning, no retry substitution', flush=True)
elif sys.argv[1] == 'run':
    protocol = json.loads((OUT/'protocol.json').read_text())
    assert sources() == protocol['source_sha256'], 'Source drift before campaign'
    try:
        run(OUT/'campaign', budget=90, repeats=1, starts=STARTS)
    finally:
        request('stop', {})
        wait_for(lambda s: s['phase']=='stopped' and not s['motion']['active'], 60)
    assert sources() == protocol['source_sha256'], 'Source drift during campaign'
    report(OUT/'campaign', OUT/'comparison')
    write_json(OUT/'final-state.json', request())
    print('DONE: six attempts retained; simulation stopped', flush=True)
else:
    raise ValueError('Use prepare or run')
