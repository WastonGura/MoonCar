"""Two fresh live Gazebo trials: hold the fixed camera or approach the ramp through Nav2."""
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.request import urlopen

from compare_survey_strategies import request,wait_for
from survey_evaluation import write_json


def run(output):
    import rclpy
    from rclpy.parameter import Parameter
    state=request()
    if state.get('autonomy',{}).get('active') or state.get('motion',{}).get('active'):
        raise ValueError('Finish the active task first')
    output.mkdir(parents=True,exist_ok=False)
    write_json(output/'plan.json',dict(start=[6.5,-2.,2.4],goal=[5.9,-1.4],
               seconds=45,baseline_seconds=5,conditions=['stationary','approach'],
               limits='One paired mechanism trial; not strategy efficacy or physical validation'))
    for condition in ('stationary','approach'):
        old=(request().get('task') or {}).get('id')
        request('apply',dict(version=1,region=[-25,-25,25,25],start=[6.5,-2.,2.4]))
        state=wait_for(lambda s:(s.get('task') or {}).get('id') not in (None,old) and s.get('motion',{}).get('ready') and s.get('session'),240)
        ident=state['task']['id'];root=Path('/evidence/frontend-experiments')/ident
        env=dict(os.environ,ROS_DOMAIN_ID='89',GZ_PARTITION='mooncar-'+ident,OPENBLAS_NUM_THREADS='1')
        destination=output/condition
        log=(output/f'{condition}.log').open('w')
        process=subprocess.Popen([sys.executable,'/source/scripts/trajectory_evaluation.py','capture',str(destination),
             '--seconds','45','--raw-depth','--world-sdf',str(root/'survey_yard.sdf'),
             '--robot-sdf','/source/reports/evidence/terrain-workbench/projection-20260913/fixed-motion/robot.sdf'],env=env,stdout=log,stderr=subprocess.STDOUT)
        rclpy.init();node=rclpy.create_node('slope_trial_clock',parameter_overrides=[Parameter('use_sim_time',value=True)])
        token=None;result=dict(condition=condition,experiment=ident,start_pose=state['motion']['pose'])
        first=None;started=False;deadline=time.monotonic()+600
        try:
            while process.poll() is None and time.monotonic()<deadline:
                rclpy.spin_once(node,timeout_sec=.1)
                manifest=destination/'manifest.json'
                if first is None and manifest.exists():
                    value=json.loads(manifest.read_text())
                    if value['status']=='recording':
                        first=node.get_clock().now().nanoseconds/1e9
                        (output/f'{condition}-start.jpg').write_bytes(urlopen('http://127.0.0.1:8766/api/simulation/scene.jpg',timeout=10).read())
                if first is not None and not started and node.get_clock().now().nanoseconds/1e9-first>=5:
                    started=True
                    result['action_started_sim_stamp']=node.get_clock().now().nanoseconds/1e9
                    if condition=='approach':token=request('move',dict(experiment=ident,goal=[5.9,-1.4]))['token']
                if token:
                    if not request('heartbeat',dict(token=token)).get('active'):token=None
            if process.poll() is None:raise TimeoutError('Capture wall-time deadline exceeded')
            result['capture_exit']=process.returncode
        except Exception as error:result['error']=str(error)
        finally:
            result['motion_before_stop']=request()['motion']
            request('cancel',{})
            if process.poll() is None:process.terminate();process.wait(timeout=20)
            result['end_motion']=request()['motion'];result['status']='completed' if process.returncode==0 and 'error' not in result else 'failed'
            write_json(output/f'{condition}-control.json',result)
            try:(output/f'{condition}-end.jpg').write_bytes(urlopen('http://127.0.0.1:8766/api/simulation/scene.jpg',timeout=10).read())
            except Exception as error:write_json(output/f'{condition}-scene-error.json',dict(error=str(error)))
            node.destroy_node();rclpy.shutdown();log.close()
        print(json.dumps(result,ensure_ascii=False),flush=True)
    request('stop',{})


if __name__=='__main__':run(Path(sys.argv[1]))
