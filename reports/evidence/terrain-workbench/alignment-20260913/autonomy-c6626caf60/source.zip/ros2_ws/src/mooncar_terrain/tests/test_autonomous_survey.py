"""Run with the existing Python/NumPy environment; no ROS needed."""
from pathlib import Path
import sys
import math
import tempfile
import threading
import unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock, patch

import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'scripts'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from autonomous_survey import choose_view,AutonomousSurvey
from terrain_map import TerrainMap


class SurveyTests(unittest.TestCase):
    def test_slow_recording_initialization_does_not_block_start_or_issue_motion(self):
        motion=Mock();motion.lock=threading.RLock()
        motion.get_clock.return_value.now.return_value.nanoseconds=0
        motion.quality={};motion.quality_received=__import__('time').monotonic()
        motion.state.return_value=dict(active=False,ready=True,pose=dict(x=0,y=0,yaw=0))
        motion.spin_client.server_is_ready.return_value=True
        survey=AutonomousSurvey(motion);release=threading.Event()
        def slow(_):
            release.wait(2)
            raise ValueError('intentional recording failure')
        with tempfile.TemporaryDirectory() as directory,patch('autonomous_survey.EvidenceRecorder',side_effect=slow):
            (Path(directory)/'test').mkdir()
            started=__import__('time').monotonic()
            response=survey.start(dict(experiment='test',budget_seconds=15,radius=6),dict(id='test'),directory)
            self.assertTrue(response['accepted'])
            self.assertLess(__import__('time').monotonic()-started,1.)
            motion.start.assert_not_called();motion.turn.assert_not_called()
            release.set();survey.worker.join(3)
            self.assertFalse(survey.data['active']);self.assertEqual(survey.data['phase'],'fault')
            motion.start.assert_not_called();motion.turn.assert_not_called()

    def test_quality_saturates_and_archive_replays_it(self):
        t=TerrainMap();xy=np.array([[x,y,0.] for x in np.arange(.01,.25,.0625) for y in np.arange(.01,.25,.0625)])
        t.add_frame(xy,1.,translation=(0,0,0));first=t.quality()['cells'][0]
        t.add_frame(xy,2.,translation=(0,0,0))
        self.assertEqual(t.quality()['cells'][0],first)
        t.add_frame(xy-[1,0,0],3.,translation=(1,0,0))
        self.assertGreater(t.quality()['cells'][0]['quality'],first['quality'])
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'test.npz';t.save(path)
            self.assertEqual(TerrainMap.load(path).quality(),t.quality())
        self.assertLessEqual(t.quality()['cells'][0]['quality'],1.)

    def test_candidate_visibility_budget_and_repeat_avoidance(self):
        grid=NS(info=NS(width=80,height=80,resolution=.25,origin=NS(position=NS(x=-10.,y=-10.))),data=[0]*6400)
        pose=dict(x=0.,y=0.,yaw=0.)
        quality=dict(resolution=.25,cells=[])
        d=choose_view(grid,quality,pose,[0,0],8,[],180)
        self.assertEqual(d['kind'],'turn')
        self.assertGreater(d['expected_new_m2'],0)
        self.assertIsNone(choose_view(grid,quality,pose,[0,0],8,[],1))
        history=[]
        for _ in range(9):
            d=choose_view(grid,quality,pose,[0,0],8,history,180)
            self.assertLess(math.hypot(d['x'],d['y']),7.25)
            history.append(d)
        self.assertTrue(any(h['kind']=='advance' for h in history))
        quality['cells']=[dict(ix=x,iy=y,quality=.2) for x in range(-40,40) for y in range(-40,40)]
        d=choose_view(grid,quality,pose,[0,0],8,[dict(x=0,y=0,yaw=a) for a in np.arange(-math.pi,math.pi,math.pi/4)],180)
        self.assertEqual(d['kind'],'resample')
        grid.data=[100]*6400
        self.assertIsNone(choose_view(grid,quality,pose,[0,0],8,[],180))

    def test_budget_stop_and_sensor_fault_revoke_motion(self):
        motion=Mock();motion.lock=threading.RLock();clock=motion.get_clock.return_value.now.return_value
        clock.nanoseconds=31_000_000_000
        survey=AutonomousSurvey(motion)
        survey.data=dict(active=True,started=0.,budget_seconds=30,history=[])
        self.assertFalse(survey.healthy());self.assertEqual(survey.state()['phase'],'budget_reached')
        motion.cancel.assert_called_once();self.assertIsNone(motion.mission_limits)
        clock.nanoseconds=0;survey.wall_started=__import__('time').monotonic()
        survey.data.update(active=True,started=0.);motion.state.return_value=dict(ready=False)
        self.assertFalse(survey.healthy());self.assertEqual(survey.state()['phase'],'fault')

    def test_interrupted_action_is_retained_and_motion_revoked(self):
        motion=Mock();motion.lock=threading.RLock()
        motion.get_clock.return_value.now.return_value.nanoseconds=0
        motion.quality=dict(resolution=.25,cells=[],stamp=0,frames=0)
        motion.quality_received=motion.grid_received=__import__('time').monotonic()
        pose=dict(x=0.,y=0.,yaw=0.)
        motion.pose.return_value=pose;motion.state.return_value=dict(ready=True,pose=pose,error='')
        survey=AutonomousSurvey(motion);survey.origin=[0,0]
        survey.data=dict(active=True,started=0.,budget_seconds=15,radius=6,history=[])
        decision=dict(x=1.,y=0.,yaw=0.,kind='advance',expected_new_m2=1.,expected_improvement_m2=0.,
                      expected_quality_gain_m2=1.,estimated_seconds=6.,visible_cells=[[0,0]])
        with patch('autonomous_survey.choose_view',return_value=decision),patch.object(survey,'execute',side_effect=lambda _:survey.stop('test interruption')):
            survey.run()
        self.assertEqual(len(survey.data['history']),1)
        record=survey.data['history'][0]
        self.assertFalse(record['success']);self.assertEqual(record['outcome'],'interrupted')
        self.assertEqual(record['roi_gain']['quality_gain_m2'],0)
        motion.cancel.assert_called_once()


if __name__=='__main__':unittest.main()
