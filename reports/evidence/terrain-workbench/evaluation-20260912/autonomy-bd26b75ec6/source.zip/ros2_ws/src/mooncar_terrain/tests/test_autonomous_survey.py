"""Run with the existing Python/NumPy environment; no ROS needed."""
from pathlib import Path
import sys
import math
import tempfile
import threading
import unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock

import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'scripts'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from autonomous_survey import choose_view,AutonomousSurvey
from terrain_map import TerrainMap


class SurveyTests(unittest.TestCase):
    def test_quality_saturates_and_archive_replays_it(self):
        t=TerrainMap();xy=np.array([[x,y,0.] for x in np.arange(.01,.25,.0625) for y in np.arange(.01,.25,.0625)])
        t.add_frame(xy,1.,translation=(0,0,0));first=t.quality()['cells'][0]
        t.add_frame(xy,2.,translation=(0,0,0))
        self.assertEqual(t.quality()['cells'][0],first)
        t.add_frame(xy-[1,0,0],3.,translation=(1,0,0))
        self.assertGreater(t.quality()['cells'][0]['quality'],first['quality'])
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'test.npz';t.save(path)
            self.assertEqual(TerrainMap.load(path).quality(),t.quality())
        self.assertLessEqual(t.quality()['cells'][0]['quality'],1.)

    def test_candidate_visibility_budget_and_repeat_avoidance(self):
        grid=NS(info=NS(width=80,height=80,resolution=.25,origin=NS(position=NS(x=-10.,y=-10.))),data=[0]*6400)
        pose=dict(x=0.,y=0.,yaw=0.)
        quality=dict(resolution=.25,cells=[])
        d=choose_view(grid,quality,pose,[0,0],8,[],180)
        self.assertEqual(d['kind'],'turn')
        self.assertGreater(d['expected_new_m2'],0)
        self.assertIsNone(choose_view(grid,quality,pose,[0,0],8,[],1))
        history=[]
        for _ in range(9):
            d=choose_view(grid,quality,pose,[0,0],8,history,180)
            self.assertLess(math.hypot(d['x'],d['y']),7.25)
            history.append(d)
        self.assertTrue(any(h['kind']=='advance' for h in history))
        quality['cells']=[dict(ix=x,iy=y,quality=.2) for x in range(-40,40) for y in range(-40,40)]
        d=choose_view(grid,quality,pose,[0,0],8,[dict(x=0,y=0,yaw=a) for a in np.arange(-math.pi,math.pi,math.pi/4)],180)
        self.assertEqual(d['kind'],'resample')
        grid.data=[100]*6400
        self.assertIsNone(choose_view(grid,quality,pose,[0,0],8,[],180))

    def test_budget_stop_and_sensor_fault_revoke_motion(self):
        motion=Mock();motion.lock=threading.RLock();clock=motion.get_clock.return_value.now.return_value
        clock.nanoseconds=31_000_000_000
        survey=AutonomousSurvey(motion)
        survey.data=dict(active=True,started=0.,budget_seconds=30,history=[])
        self.assertFalse(survey.healthy());self.assertEqual(survey.state()['phase'],'budget_reached')
        motion.cancel.assert_called_once();self.assertIsNone(motion.mission_limits)
        clock.nanoseconds=0;survey.wall_started=__import__('time').monotonic()
        survey.data.update(active=True,started=0.);motion.state.return_value=dict(ready=False)
        self.assertFalse(survey.healthy());self.assertEqual(survey.state()['phase'],'fault')


if __name__=='__main__':unittest.main()
